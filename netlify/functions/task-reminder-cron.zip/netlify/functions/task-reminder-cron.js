var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var task_reminder_cron_exports = {};
__export(task_reminder_cron_exports, {
  handler: () => handler,
  myHandler: () => myHandler
});
module.exports = __toCommonJS(task_reminder_cron_exports);
var import_functions = require("@netlify/functions");
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
var import_node_fetch = __toESM(require("node-fetch"), 1);
if (!import_firebase_admin.default.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      import_firebase_admin.default.initializeApp({
        credential: import_firebase_admin.default.credential.cert(serviceAccount)
      });
      console.log("Firebase Admin successfully initialized in Task Reminder function.");
    } else {
      console.warn("FIREBASE_SERVICE_ACCOUNT env var not found. Running in mockup fallback mode.");
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error in Task Reminder function:", error);
  }
}
let dbInstance = null;
function getFirestoreDb() {
  if (dbInstance) return dbInstance;
  if (!import_firebase_admin.default.apps.length) {
    throw new Error("Firebase Admin not initialized. Check FIREBASE_SERVICE_ACCOUNT env var.");
  }
  dbInstance = import_firebase_admin.default.firestore();
  try {
    dbInstance.settings({ databaseId: "default" });
  } catch (settingsErr) {
    console.log("Database settings already applied or failed to apply:", settingsErr.message);
  }
  return dbInstance;
}
const getReminderMarkdown = (taskTitle, assignerName, startTimeStr, deadlineStr, timeLabel) => {
  return `### \u26A0\uFE0F **ME Cloud Academy**
**Learning Task Deadline Approaching!**

---

**\u{1F6A8} Time Remaining:** **${timeLabel}**

**\u{1F4CB} Task Details:**
* \u{1F3F7}\uFE0F **Task Name:** ${taskTitle}
* \u{1F464} **Assigner:** ${assignerName}
* \u{1F4C5} **Start Time:** ${startTimeStr}
* \u23F0 **Final Deadline:** ${deadlineStr}

---

> \u{1F4A1} *This is a friendly reminder that you have not yet completed your learning reflections for this task. Please listen to the assigned recordings and submit your reflections before the deadline to ensure your progress is recorded.*

[\u{1F449} Click Here to Resume Learning](dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fteam-tasks)`;
};
const myHandler = async (event, context) => {
  console.log("[Task Reminder Cron] Job triggered at:", (/* @__PURE__ */ new Date()).toISOString());
  const appKey = process.env.DINGTALK_APP_KEY;
  const appSecret = process.env.DINGTALK_APP_SECRET;
  const agentId = process.env.DINGTALK_AGENT_ID;
  const isMockDingTalk = !appKey || !appSecret || appKey.includes("your_") || appSecret.includes("your_");
  const isMockFirebase = !import_firebase_admin.default.apps.length;
  const diagnostics = {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    isMockFirebase,
    isMockDingTalk,
    scannedTasks: [],
    errors: []
  };
  let db;
  try {
    db = getFirestoreDb();
  } catch (dbErr) {
    console.warn("[Task Reminder Cron] Firestore connection unavailable. Skipping reminder scan:", dbErr.message);
    diagnostics.errors.push("Firebase Admin is not configured: " + dbErr.message);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, diagnostics })
    };
  }
  try {
    let accessToken = null;
    if (!isMockDingTalk) {
      try {
        const tokenRes = await (0, import_node_fetch.default)(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
        const tokenData = await tokenRes.json();
        if (tokenData.errcode === 0) {
          accessToken = tokenData.access_token;
        } else {
          console.error("[Task Reminder Cron] Failed to exchange DingTalk token:", tokenData.errmsg);
          diagnostics.errors.push(`DingTalk token exchange error: [${tokenData.errcode}] ${tokenData.errmsg}`);
        }
      } catch (tokenErr) {
        console.error("[Task Reminder Cron] DingTalk token request network error:", tokenErr.message);
        diagnostics.errors.push("DingTalk token request network error: " + tokenErr.message);
      }
    }
    const now = import_firebase_admin.default.firestore.Timestamp.now();
    const snapshot = await db.collection("learning_tasks").where("deadline", ">", now).get();
    console.log(`[Task Reminder Cron] Scanning ${snapshot.size} active learning tasks...`);
    for (const doc of snapshot.docs) {
      const task = { id: doc.id, ...doc.data() };
      if (!task.deadline) {
        diagnostics.scannedTasks.push({
          id: task.id,
          title: task.title || "Untitled",
          error: "Task has no deadline field."
        });
        continue;
      }
      let deadlineDate;
      try {
        if (typeof task.deadline.toDate === "function") {
          deadlineDate = task.deadline.toDate();
        } else if (task.deadline instanceof Date) {
          deadlineDate = task.deadline;
        } else if (task.deadline.seconds) {
          deadlineDate = new Date(task.deadline.seconds * 1e3);
        } else if (task.deadline._seconds) {
          deadlineDate = new Date(task.deadline._seconds * 1e3);
        } else {
          deadlineDate = new Date(task.deadline);
        }
      } catch (parseErr) {
        console.error(`[Task Reminder Cron] Failed to parse deadline for task ID ${task.id}:`, parseErr.message);
        diagnostics.scannedTasks.push({
          id: task.id,
          title: task.title || "Untitled",
          error: "Failed to parse deadline: " + parseErr.message
        });
        continue;
      }
      const msRemaining = deadlineDate.getTime() - Date.now();
      const minsRemaining = Math.floor(msRemaining / (60 * 1e3));
      let triggerReminder = null;
      let reminderField = null;
      let timeLabel = null;
      if (minsRemaining <= 30 && minsRemaining > 0 && !task.reminder30mSent) {
        triggerReminder = "30m";
        reminderField = "reminder30mSent";
        timeLabel = "30 Minutes";
      } else if (minsRemaining <= 60 && minsRemaining > 30 && !task.reminder1hSent) {
        triggerReminder = "1h";
        reminderField = "reminder1hSent";
        timeLabel = "1 Hour";
      }
      const taskDiagnostic = {
        id: task.id,
        title: task.title,
        deadline: deadlineDate.toISOString(),
        minsRemaining,
        reminder1hSent: !!task.reminder1hSent,
        reminder30mSent: !!task.reminder30mSent,
        triggerReminder,
        timeLabel
      };
      if (!triggerReminder) {
        taskDiagnostic.action = "No warning window triggered. Remaining minutes: " + minsRemaining;
        diagnostics.scannedTasks.push(taskDiagnostic);
        continue;
      }
      console.log(`[Task Reminder Cron] Task "${task.title}" (ID: ${task.id}) is due for ${timeLabel} warning (Deadline: ${deadlineDate.toLocaleString()}).`);
      const pendingAssigneeIds = Object.entries(task.assignees || {}).filter(([_, a]) => a.status === "pending").map(([uid, _]) => uid);
      taskDiagnostic.pendingAssignees = pendingAssigneeIds;
      if (pendingAssigneeIds.length === 0) {
        console.log(`[Task Reminder Cron] All assignees have completed Task "${task.title}". Marking ${reminderField} as true.`);
        taskDiagnostic.action = "All assignees completed. Marked reminder as sent.";
        await db.collection("learning_tasks").doc(task.id).update({
          [reminderField]: true
        });
        diagnostics.scannedTasks.push(taskDiagnostic);
        continue;
      }
      const dingtalkUserIds = [];
      for (const uid of pendingAssigneeIds) {
        const userDoc = await db.collection("users").doc(uid).get();
        if (userDoc.exists && userDoc.data().dingtalkUserId) {
          dingtalkUserIds.push(userDoc.data().dingtalkUserId);
        }
      }
      taskDiagnostic.dingtalkUserIds = dingtalkUserIds;
      if (dingtalkUserIds.length === 0) {
        console.log(`[Task Reminder Cron] No linked DingTalk User IDs found for pending assignees of Task "${task.title}". Marking ${reminderField} as true.`);
        taskDiagnostic.action = "No linked DingTalk User IDs found. Marked reminder as sent.";
        await db.collection("learning_tasks").doc(task.id).update({
          [reminderField]: true
        });
        diagnostics.scannedTasks.push(taskDiagnostic);
        continue;
      }
      let startTimeStr = "-";
      if (task.createdAt) {
        try {
          let createdDate;
          if (typeof task.createdAt.toDate === "function") {
            createdDate = task.createdAt.toDate();
          } else if (task.createdAt instanceof Date) {
            createdDate = task.createdAt;
          } else if (task.createdAt.seconds) {
            createdDate = new Date(task.createdAt.seconds * 1e3);
          } else if (task.createdAt._seconds) {
            createdDate = new Date(task.createdAt._seconds * 1e3);
          } else {
            createdDate = new Date(task.createdAt);
          }
          startTimeStr = createdDate.toLocaleString();
        } catch (e) {
          console.warn("Failed to parse task.createdAt:", e.message);
        }
      }
      const markdownText = getReminderMarkdown(
        task.title,
        task.assignerName || "Leader",
        startTimeStr,
        deadlineDate.toLocaleString(),
        timeLabel
      );
      let sentSuccess = false;
      let apiErrMessage = null;
      if (accessToken && agentId) {
        try {
          const notifyUrl = `https://oapi.dingtalk.com/topapi/message/corpconversation/asyncsend_v2?access_token=${accessToken}`;
          const response = await (0, import_node_fetch.default)(notifyUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              agent_id: parseInt(agentId),
              userid_list: dingtalkUserIds.join(","),
              msg: {
                msgtype: "markdown",
                markdown: {
                  title: `\u26A0\uFE0F Task Deadline Reminder`,
                  text: markdownText
                }
              }
            })
          });
          const notifyData = await response.json();
          if (notifyData.errcode === 0) {
            sentSuccess = true;
            console.log(`[Task Reminder Cron] DingTalk Corp Message sent successfully for Task "${task.title}" to: ${dingtalkUserIds.join(",")}`);
            taskDiagnostic.action = `Notification sent successfully to ${dingtalkUserIds.join(",")}`;
          } else {
            console.error(`[Task Reminder Cron] DingTalk message send failed: [${notifyData.errcode}] ${notifyData.errmsg}`);
            apiErrMessage = `DingTalk send failed: [${notifyData.errcode}] ${notifyData.errmsg}`;
            taskDiagnostic.action = `Error: ${apiErrMessage}`;
          }
        } catch (err) {
          console.error(`[Task Reminder Cron] DingTalk message API query network exception:`, err.message);
          apiErrMessage = `DingTalk API Exception: ${err.message}`;
          taskDiagnostic.action = `Error: ${apiErrMessage}`;
        }
      } else {
        sentSuccess = true;
        console.log(`[Mock Task Reminder Cron] Triggered ${timeLabel} warning for Task "${task.title}" (Mock recipients: ${dingtalkUserIds.join(",")})`);
        taskDiagnostic.action = `Mock notification completed for ${dingtalkUserIds.join(",")}`;
      }
      taskDiagnostic.sentSuccess = sentSuccess;
      if (apiErrMessage) {
        taskDiagnostic.apiError = apiErrMessage;
        diagnostics.errors.push(`Task "${task.title}": ${apiErrMessage}`);
      }
      if (sentSuccess) {
        await db.collection("learning_tasks").doc(task.id).update({
          [reminderField]: true
        });
      }
      diagnostics.scannedTasks.push(taskDiagnostic);
    }
  } catch (err) {
    console.error("[Task Reminder Cron] Job encountered error:", err);
    diagnostics.errors.push("Job general error: " + err.message);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, diagnostics })
    };
  }
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ success: true, diagnostics })
  };
};
const handler = (0, import_functions.schedule)("*/5 * * * *", myHandler);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler,
  myHandler
});
