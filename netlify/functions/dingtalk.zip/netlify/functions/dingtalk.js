var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var dingtalk_exports = {};
__export(dingtalk_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(dingtalk_exports);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
if (!import_firebase_admin.default.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      import_firebase_admin.default.initializeApp({
        credential: import_firebase_admin.default.credential.cert(serviceAccount)
      });
      console.log("Firebase Admin successfully initialized in DingTalk function.");
    } else {
      console.warn("FIREBASE_SERVICE_ACCOUNT env var not found. Running in mockup fallback mode.");
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error in DingTalk function:", error);
  }
}
let dbInstance = null;
function getFirestoreDb() {
  if (dbInstance) return dbInstance;
  if (!import_firebase_admin.default.apps.length) {
    throw new Error("Firebase Admin not initialized. Check FIREBASE_SERVICE_ACCOUNT env var.");
  }
  dbInstance = import_firebase_admin.default.firestore();
  try {
    dbInstance.settings({ databaseId: "default" });
  } catch (settingsErr) {
    console.log("Database settings already applied or failed to apply:", settingsErr.message);
  }
  return dbInstance;
}
const CUSTOM_DINGTALK_EMAIL_MAP = {
  "serdah": "mohserdah@51talk.com"
};
function getDingTalkEmail(crmId) {
  const key = crmId.trim().toLowerCase().replace(/\s+/g, "");
  if (CUSTOM_DINGTALK_EMAIL_MAP[key]) {
    return CUSTOM_DINGTALK_EMAIL_MAP[key];
  }
  return `${key}@51talk.com`;
}
function isUserChineseSpeaker(userData) {
  if (!userData) return false;
  const role = String(userData.role || "").trim().toLowerCase();
  const crmId = String(userData.crmId || "").trim().toLowerCase();
  const isSdOrAbove = role === "sd" || role === "admin" || role === "super_admin";
  const isWuchuan = crmId === "wuchuan";
  return isSdOrAbove || isWuchuan;
}
async function searchDingTalkUser(accessToken, queryWord, logs) {
  try {
    const res = await fetch(`https://api.dingtalk.com/v1.0/contact/users/search`, {
      method: "POST",
      headers: {
        "x-acs-dingtalk-access-token": accessToken,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        queryWord,
        offset: 0,
        size: 20
      })
    });
    const data = await res.json();
    if (data && data.code) {
      logs.push({ msg: `\u26A0\uFE0F [\u68C0\u7D22\u63A5\u53E3\u5F02\u5E38] \u641C\u7D22\u8BCD [${queryWord}] \u63A5\u53E3\u8FD4\u56DE\u9519\u8BEF: [${data.code}] ${data.message}\u3002\u8BF7\u524D\u5F80\u9489\u9489\u5F00\u53D1\u8005\u540E\u53F0->\u6743\u9650\u7BA1\u7406->\u901A\u8BAF\u5F55\u7BA1\u7406\u4E2D\uFF0C\u7533\u8BF7\u5E76\u5F00\u901A\u3010\u641C\u7D22\u4F01\u4E1A\u901A\u8BAF\u5F55\u7684\u6743\u9650\u3011\uFF01`, type: "error" });
      return [];
    }
    if (data && Array.isArray(data.list)) {
      return data.list;
    }
    return [];
  } catch (err) {
    console.error(`Search failed for query "${queryWord}":`, err);
    logs.push({ msg: `\u26A0\uFE0F [\u68C0\u7D22\u7F51\u7EDC\u5F02\u5E38] \u641C\u7D22\u8BCD [${queryWord}] \u63A5\u53E3\u8BF7\u6C42\u5931\u8D25: ${err.message}`, type: "error" });
    return [];
  }
}
async function getDingTalkUserDetails(accessToken, userId) {
  try {
    const res = await fetch(`https://oapi.dingtalk.com/topapi/v2/user/get?access_token=${accessToken}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userid: userId })
    });
    const data = await res.json();
    if (data.errcode === 0 && data.result) {
      return data.result;
    }
    return null;
  } catch (err) {
    console.error(`Failed to get details for userid "${userId}":`, err);
    return null;
  }
}
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { action } = body;
    const appKey = process.env.DINGTALK_APP_KEY;
    const appSecret = process.env.DINGTALK_APP_SECRET;
    const agentId = process.env.DINGTALK_AGENT_ID;
    const webhookUrl = process.env.DINGTALK_WEBHOOK_URL;
    const isMockDingTalk = !appKey || !appSecret || appKey.includes("your_") || appSecret.includes("your_");
    const isMockFirebase = !import_firebase_admin.default.apps.length;
    if (action === "sync") {
      const logs = [];
      let linkedCount = 0;
      if (isMockDingTalk) {
        logs.push({ msg: "\u26A0\uFE0F [\u672A\u914D\u7F6E\u51ED\u8BC1] \u9489\u9489 AppKey/AppSecret \u672A\u5728\u73AF\u5883\u53D8\u91CF\u4E2D\u914D\u7F6E\uFF0C\u7CFB\u7EDF\u6B63\u5728\u8FD0\u884C\u5728\u3010\u9AD8\u7EA7\u6A21\u62DF(Mock)\u6D4B\u8BD5\u73AF\u5883\u3011\u4E2D...", type: "error" });
      }
      const userIdsToSync = body.userIds;
      let users = [];
      if (!isMockFirebase) {
        try {
          const db = getFirestoreDb();
          if (userIdsToSync && Array.isArray(userIdsToSync) && userIdsToSync.length > 0) {
            for (const uid of userIdsToSync) {
              const doc = await db.collection("users").doc(uid).get();
              if (doc.exists) {
                users.push({ id: doc.id, ...doc.data() });
              }
            }
            logs.push({ msg: `\u{1F4C2} [\u6570\u636E\u5E93\u8FDE\u63A5\u6210\u529F] \u5DF2\u5B9A\u4F4D\u6279\u6B21\u5185 ${users.length} \u4E2A\u8D26\u53F7\u6863\u6848\u3002`, type: "success" });
          } else {
            const snapshot = await db.collection("users").get();
            snapshot.forEach((doc) => {
              users.push({ id: doc.id, ...doc.data() });
            });
            logs.push({ msg: `\u{1F4C2} [\u6570\u636E\u5E93\u8FDE\u63A5\u6210\u529F] \u81EA Firestore \u8BFB\u53D6\u5230\u5171 ${users.length} \u4E2A\u7CFB\u7EDF\u8D26\u6237\u3002`, type: "success" });
          }
        } catch (fsErr) {
          console.error("Firestore read error:", fsErr);
          logs.push({ msg: `\u274C [\u6570\u636E\u5E93\u6545\u969C] \u8BFB\u53D6 Firestore \u7528\u6237\u8868\u5931\u8D25\uFF0C\u8FDB\u5165\u5B8C\u5168\u6A21\u62DF\u6D4B\u8BD5\uFF1A${fsErr.message}`, type: "error" });
          users = getMockUserRecords();
        }
      } else {
        logs.push({ msg: "\u2139\uFE0F [\u65E0\u6570\u636E\u5E93\u670D\u52A1] \u6B63\u5728\u4EE5\u672C\u5730\u5185\u5B58 Mock \u6570\u636E\u96C6\u6A21\u62DF\u7528\u6237\u5217\u8868\u8FDB\u884C\u540C\u6B65...", type: "success" });
        users = getMockUserRecords();
      }
      const targetUsers = users.filter((u) => u.role !== "super_admin");
      logs.push({ msg: `\u{1F504} [\u5F00\u59CB\u540C\u6B65] \u7B5B\u9009\u51FA ${targetUsers.length} \u4E2A\u975E\u8D85\u7EA7\u7BA1\u7406\u5458\u8D26\u6237\u5F00\u5C55\u9489\u9489\u5339\u914D...`, type: "success" });
      let accessToken = null;
      if (!isMockDingTalk) {
        try {
          logs.push({ msg: "\u{1F510} [\u9274\u6743] \u6B63\u5728\u8BF7\u6C42\u9489\u9489\u5B98\u65B9 Token...", type: "success" });
          const tokenRes = await fetch(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
          const tokenData = await tokenRes.json();
          if (tokenData.errcode === 0) {
            accessToken = tokenData.access_token;
            logs.push({ msg: "\u{1F513} [\u9274\u6743\u6210\u529F] \u9489\u9489 Access Token \u83B7\u53D6\u6210\u529F\uFF0C\u5DF2\u5EFA\u7ACB\u5B89\u5168\u4FE1\u9053\u5E76\u5F00\u542F\u3010\u7CBE\u786E\u5B9A\u5411\u67E5\u8BE2\u901A\u9053\u3011\u3002", type: "success" });
          } else {
            logs.push({ msg: `\u274C [\u9274\u6743\u5931\u8D25] \u9489\u9489\u8FD4\u56DE\u9519\u8BEF: [${tokenData.errcode}] ${tokenData.errmsg}\u3002\u964D\u7EA7\u4E3A\u6A21\u62DF\u5339\u914D\u6A21\u5F0F...`, type: "error" });
          }
        } catch (authErr) {
          console.error("DingTalk Auth Error:", authErr);
          logs.push({ msg: `\u274C [\u9274\u6743\u6545\u969C] \u8FDE\u63A5\u9489\u9489\u670D\u52A1\u5668\u8D85\u65F6\uFF0C\u964D\u7EA7\u4E3A\u6A21\u62DF\u5339\u914D\u6A21\u5F0F: ${authErr.message}`, type: "error" });
        }
      }
      for (const user of targetUsers) {
        const crmId = user.crmId || user.id;
        const email = (user.email || getDingTalkEmail(crmId)).trim().toLowerCase();
        let ddUserId = null;
        let alreadyLinked = !!user.dingtalkUserId;
        if (alreadyLinked) {
          ddUserId = user.dingtalkUserId;
          logs.push({ msg: `\u{1F517} [\u8DF3\u8FC7] \u9500\u552E [${crmId}] (${email}) \u5DF2\u624B\u52A8\u6216\u5386\u53F2\u5173\u8054\u9489\u9489 ID: ${ddUserId}\uFF0C\u65E0\u9700\u91CD\u590D\u540C\u6B65\u3002`, type: "success" });
          linkedCount++;
          continue;
        }
        if (!isMockDingTalk && accessToken) {
          try {
            const emailPrefix = email.split("@")[0];
            const nameSegment = crmId.split("-").pop();
            const searchTerms = Array.from(/* @__PURE__ */ new Set([
              crmId,
              emailPrefix,
              nameSegment,
              emailPrefix.length >= 5 ? emailPrefix.substring(0, 5) : null,
              nameSegment.length >= 5 ? nameSegment.substring(0, 5) : null,
              emailPrefix.toLowerCase().startsWith("moh") ? "mohammad" : null,
              emailPrefix.toLowerCase().startsWith("moh") ? "mohammed" : null
            ])).filter(Boolean);
            logs.push({ msg: `\u{1F50D} [\u7CBE\u51C6\u5339\u914D] \u6B63\u5728\u9488\u5BF9\u9500\u552E [${crmId}] (${email}) \u7684\u4E2A\u4EBA\u7279\u5F81\uFF0C\u542F\u52A8\u591A\u91CD\u901A\u8BAF\u5F55\u5B9A\u5411\u68C0\u7D22...`, type: "success" });
            let matched = false;
            for (const term of searchTerms) {
              if (matched) break;
              const foundUserIds = await searchDingTalkUser(accessToken, term, logs);
              if (foundUserIds && foundUserIds.length > 0) {
                const detailsList = await Promise.all(
                  foundUserIds.map((uid) => getDingTalkUserDetails(accessToken, uid))
                );
                for (const details of detailsList) {
                  if (details) {
                    const ddEmail = (details.email || "").trim().toLowerCase();
                    const ddOrgEmail = (details.org_email || "").trim().toLowerCase();
                    const ddName = (details.name || "").trim().toLowerCase();
                    const ddUserid = (details.userid || "").trim().toLowerCase();
                    if (ddEmail === email || ddOrgEmail === email || ddName === crmId.toLowerCase() || ddUserid === emailPrefix) {
                      ddUserId = details.userid;
                      matched = true;
                      logs.push({ msg: `\u2705 [\u5339\u914D\u6210\u529F] \u6210\u529F\u5728\u901A\u8BAF\u5F55\u4E2D\u7CBE\u51C6\u8BC6\u522B\u5230\u9500\u552E [${crmId}] \u5173\u8054\u7684\u9489\u9489\u7528\u6237 [${details.name}]\uFF0C\u5339\u914D\u5DE5\u53F7: ${ddUserId}`, type: "success" });
                      break;
                    } else {
                      logs.push({ msg: `\u2139\uFE0F [\u7279\u5F81\u6BD4\u5BF9] \u627E\u5230\u540C\u540D/\u5DE5\u53F7\u5339\u914D\u5019\u9009\u4EBA [${details.name}] (\u5DE5\u53F7: ${details.userid})\uFF0C\u4F46\u5176\u9489\u9489\u7ED1\u5B9A\u90AE\u7BB1\u4E3A [\u4E3B: ${details.email || "\u672A\u516C\u5F00/\u672A\u914D\u7F6E"}] / [\u4F01\u4E1A: ${details.org_email || "\u672A\u516C\u5F00/\u672A\u914D\u7F6E"}]\uFF0C\u4E0E\u76EE\u6807 [${email}] \u4E0D\u4E00\u81F4\uFF0C\u5339\u914D\u5931\u8D25\u3002`, type: "error" });
                    }
                  }
                }
              }
            }
            if (!matched) {
              logs.push({ msg: `\u2139\uFE0F [\u672A\u5339\u914D] \u9500\u552E [${crmId}] (${email}) \u5728\u60A8\u7684\u4F01\u4E1A\u9489\u9489\u901A\u8BAF\u5F55\u4E2D\u672A\u627E\u5230\uFF08\u8BF7\u786E\u4FDD\u8BE5\u6210\u5458\u5DF2\u52A0\u5165\u4F01\u4E1A\u4E14\u90AE\u7BB1\u4E00\u81F4\uFF09\u3002`, type: "error" });
            }
          } catch (apiErr) {
            console.error("DingTalk API query error for user:", crmId, apiErr);
            logs.push({ msg: `\u26A0\uFE0F [\u7F51\u7EDC\u6545\u969C] \u9500\u552E [${crmId}] \u63A5\u53E3\u67E5\u8BE2\u5F02\u5E38: ${apiErr.message}`, type: "error" });
          }
        } else {
          ddUserId = `dd_mock_${crmId.replace(/[^a-zA-Z0-9]/g, "") || Math.floor(Math.random() * 1e5)}`;
          logs.push({ msg: `\u2728 [Mock \u5173\u8054] \u9500\u552E [${crmId}] (${email}) \u6210\u529F\u6A21\u62DF\u5339\u914D\uFF0C\u81EA\u52A8\u5173\u8054\u6D4B\u8BD5 ID: ${ddUserId}`, type: "success" });
        }
        if (ddUserId) {
          linkedCount++;
          const syncTime = (/* @__PURE__ */ new Date()).toISOString();
          if (!isMockFirebase) {
            try {
              const db = getFirestoreDb();
              await db.collection("users").doc(user.id).update({
                dingtalkUserId: ddUserId,
                dingtalkSyncedAt: syncTime
              });
            } catch (dbErr) {
              console.error("Failed to write sync to Firestore for user:", user.id, dbErr);
              logs.push({ msg: `\u274C [\u6570\u636E\u5E93\u5199\u5165\u5931\u8D25] \u9500\u552E [${crmId}] \u7684\u5339\u914D\u7ED3\u679C\u672A\u80FD\u6301\u4E45\u5316: ${dbErr.message}`, type: "error" });
            }
          } else {
            user.dingtalkUserId = ddUserId;
            user.dingtalkSyncedAt = syncTime;
          }
        }
      }
      logs.push({ msg: `\u{1F389} [\u540C\u6B65\u5B8C\u6210] \u7ED3\u675F\u672C\u6B21\u9489\u9489\u5173\u8054\uFF0C\u6210\u529F\u5C06 ${linkedCount} / ${targetUsers.length} \u4E2A\u9500\u552E\u8D26\u6237\u7ED1\u5B9A\u81F3\u9489\u9489\u3002`, type: "success" });
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          success: true,
          linkedCount,
          logs: logs.reverse()
        })
      };
    }
    if (action === "login") {
      const { code } = body;
      if (!code) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing code" }) };
      }
      let resolvedCrmId = null;
      let resolvedUserId = null;
      if (code.startsWith("mock_auth_code_")) {
        resolvedCrmId = code.replace("mock_auth_code_", "");
        console.log(`[Mock SSO Login] Simulating OAuth login for crmId: ${resolvedCrmId}`);
        if (!isMockFirebase) {
          try {
            const db = getFirestoreDb();
            const snapshot = await db.collection("users").where("crmId", "==", resolvedCrmId).limit(1).get();
            if (!snapshot.empty) {
              resolvedUserId = snapshot.docs[0].id;
            }
          } catch (dbErr) {
            console.error("Firebase read error during mock login:", dbErr);
          }
        }
        if (!resolvedUserId) {
          resolvedUserId = `mock_uid_${resolvedCrmId}`;
          if (!isMockFirebase) {
            try {
              const db = getFirestoreDb();
              await db.collection("users").doc(resolvedUserId).set({
                crmId: resolvedCrmId,
                role: "user",
                team: "Mock-Team",
                dep: "CC",
                permissions: { manageCategories: false, manageRecordings: false, manageUsers: false, manageDashboard: false, manageTasks: false }
              }, { merge: true });
            } catch (createErr) {
              console.error("Failed to create mock user doc in Firestore:", createErr);
            }
          }
        }
      } else {
        if (isMockDingTalk) {
          return {
            statusCode: 400,
            body: JSON.stringify({ error: "DingTalk AppKey/Secret are not configured. Cannot perform real SSO. Please use account and password, or click the mock test button." })
          };
        }
        try {
          const tokenRes = await fetch(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
          const tokenData = await tokenRes.json();
          if (tokenData.errcode !== 0) {
            return { statusCode: 500, body: JSON.stringify({ error: `DingTalk auth token exchange failed: ${tokenData.errmsg}` }) };
          }
          const token = tokenData.access_token;
          const userInfoRes = await fetch(`https://oapi.dingtalk.com/topapi/v2/user/getuserinfo?access_token=${token}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code })
          });
          const userInfoData = await userInfoRes.json();
          if (userInfoData.errcode !== 0 || !userInfoData.result || !userInfoData.result.userid) {
            return { statusCode: 400, body: JSON.stringify({ error: `DingTalk SSO authentication failed: ${userInfoData.errmsg}` }) };
          }
          const ddUserId = userInfoData.result.userid;
          if (isMockFirebase) {
            return {
              statusCode: 500,
              body: JSON.stringify({ error: "Database service account is not configured. Real SSO cannot match accounts. Please contact admin." })
            };
          }
          const db = getFirestoreDb();
          const snapshot = await db.collection("users").where("dingtalkUserId", "==", ddUserId).limit(1).get();
          if (snapshot.empty) {
            return {
              statusCode: 400,
              body: JSON.stringify({ error: "\u60A8\u5F53\u524D\u7684\u9489\u9489\u8D26\u53F7\u672A\u4E0E ME \u4E91\u5B66\u5802\u7ED1\u5B9A\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u6216\u4F7F\u7528\u8D26\u53F7\u5BC6\u7801\u767B\u5F55\uFF01 / Your DingTalk account is not bound to ME Cloud Academy. Please contact administrator or login with account & password." })
            };
          }
          resolvedUserId = snapshot.docs[0].id;
          resolvedCrmId = snapshot.docs[0].data().crmId;
        } catch (oauthErr) {
          console.error("SSO Login Error:", oauthErr);
          return { statusCode: 500, body: JSON.stringify({ error: `SSO login connection error: ${oauthErr.message}` }) };
        }
      }
      if (isMockFirebase) {
        console.log(`[Mock Firebase Admin] Simulating Firebase Auth Token generation for user: ${resolvedUserId}`);
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: true,
            customToken: `mock_firebase_token_for_${resolvedUserId}`,
            username: resolvedCrmId
          })
        };
      }
      try {
        const customToken = await import_firebase_admin.default.auth().createCustomToken(resolvedUserId);
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: true,
            customToken,
            username: resolvedCrmId
          })
        };
      } catch (tokenErr) {
        console.error("Auth Token generation error:", tokenErr);
        return { statusCode: 500, body: JSON.stringify({ error: `Failed to create secure auth session: ${tokenErr.message}` }) };
      }
    }
    if (action === "notifyTask") {
      const { title, assignerName, assigneeIds, deadline, startTime } = body;
      if (!assigneeIds || !Array.isArray(assigneeIds)) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing assigneeIds" }) };
      }
      const finalStartTime = startTime || (/* @__PURE__ */ new Date()).toLocaleString();
      const recipientsZh = [];
      const recipientsEn = [];
      let dbError = null;
      const queryLogs = [];
      if (!isMockFirebase) {
        try {
          const db = getFirestoreDb();
          for (const uid of assigneeIds) {
            const doc = await db.collection("users").doc(uid).get();
            if (doc.exists) {
              const data = doc.data();
              if (data.dingtalkUserId) {
                const isEnglishSpeaker = !isUserChineseSpeaker(data);
                if (isEnglishSpeaker) {
                  recipientsEn.push(data.dingtalkUserId);
                } else {
                  recipientsZh.push(data.dingtalkUserId);
                }
                queryLogs.push({ uid, found: true, dingtalkUserId: data.dingtalkUserId, crmId: data.crmId, lang: isEnglishSpeaker ? "en" : "zh" });
              } else {
                queryLogs.push({ uid, found: true, dingtalkUserId: null, crmId: data.crmId, msg: "dingtalkUserId is missing in database profile" });
              }
            } else {
              queryLogs.push({ uid, found: false, msg: "User document not found in Firestore users collection" });
            }
          }
        } catch (err) {
          console.error("Failed to query assignees dingtalkUserIds:", err);
          dbError = err.message;
        }
      } else {
        assigneeIds.forEach((id) => {
          const mockId = `dd_mock_id_${id}`;
          if (id.toLowerCase().includes("wuchuan")) {
            recipientsZh.push(mockId);
          } else {
            recipientsEn.push(mockId);
          }
          queryLogs.push({ uid: id, found: true, dingtalkUserId: mockId, msg: "mocked" });
        });
      }
      const getMsgMarkdown = (lang) => {
        if (lang === "en") {
          return `### \u{1F4DA} **ME Cloud Academy**
**New Learning Task Assigned**

---

**\u{1F4CB} Task Details:**
* \u{1F3F7}\uFE0F **Task Name:** ${title}
* \u{1F4C5} **Start Time:** ${finalStartTime}
* \u23F0 **Deadline:** ${deadline || "-"}
* \u{1F464} **Assigner:** ${assignerName}

---

> \u{1F4A1} *Reviewing sales recordings is vital for professional growth. Please listen to the assigned recordings and submit your reflections before the deadline.*

[\u{1F449} Click Here to Start Learning](dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fteam-tasks)`;
        }
        return `### \u{1F4DA} **ME \u4E91\u5B66\u5802**
**\u6536\u5230\u65B0\u7684\u5B66\u4E60\u4EFB\u52A1**

---

**\u{1F4CB} \u4EFB\u52A1\u8BE6\u60C5\uFF1A**
* \u{1F3F7}\uFE0F **\u4EFB\u52A1\u540D\u79F0**\uFF1A${title}
* \u{1F4C5} **\u5F00\u59CB\u65F6\u95F4**\uFF1A${finalStartTime}
* \u23F0 **\u622A\u6B62\u65F6\u95F4**\uFF1A${deadline || "-"}
* \u{1F464} **\u6307\u6D3E\u5BFC\u5E08**\uFF1A${assignerName}

---

> \u{1F4A1} *\u4F18\u79C0\u7684\u9500\u552E\u5F55\u97F3\u590D\u76D8\uFF0C\u80FD\u52A9\u63A8\u4E13\u4E1A\u6210\u957F\u3002\u8BF7\u53CA\u65F6\u5728\u622A\u6B62\u65E5\u671F\u524D\u542C\u5B8C\u76F8\u5173\u5F55\u97F3\u5E76\u63D0\u4EA4\u5FC3\u5F97\u611F\u609F\u3002*

[\u{1F449} \u70B9\u51FB\u7ACB\u5373\u5F00\u59CB\u5B66\u4E60](dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fteam-tasks)`;
      };
      const getMsgTitle = (lang) => {
        return lang === "en" ? "\u{1F4DA} ME Cloud Academy - New Task" : "\u{1F4DA} ME \u4E91\u5B66\u5802 - \u65B0\u5B66\u4E60\u4EFB\u52A1\u6307\u6D3E";
      };
      let sentSuccess = false;
      let mockPayload = null;
      let dingtalkApiResponse = [];
      let errorMessage = null;
      if (!isMockDingTalk && agentId && (recipientsZh.length > 0 || recipientsEn.length > 0)) {
        try {
          const tokenRes = await fetch(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
          const tokenData = await tokenRes.json();
          if (tokenData.errcode === 0) {
            const token = tokenData.access_token;
            const sendNotification = async (recipientsList, lang) => {
              if (recipientsList.length === 0) return { success: true };
              const notifyUrl = `https://oapi.dingtalk.com/topapi/message/corpconversation/asyncsend_v2?access_token=${token}`;
              const notifyRes = await fetch(notifyUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  agent_id: parseInt(agentId),
                  userid_list: recipientsList.join(","),
                  msg: {
                    msgtype: "markdown",
                    markdown: {
                      title: getMsgTitle(lang),
                      text: getMsgMarkdown(lang)
                    }
                  }
                })
              });
              const notifyData = await notifyRes.json();
              dingtalkApiResponse.push({ lang, data: notifyData });
              if (notifyData.errcode === 0) {
                return { success: true };
              } else {
                return { success: false, error: `DingTalk API returned errcode ${notifyData.errcode}: ${notifyData.errmsg}` };
              }
            };
            const enResult = await sendNotification(recipientsEn, "en");
            const zhResult = await sendNotification(recipientsZh, "zh");
            sentSuccess = enResult.success && zhResult.success;
            if (!sentSuccess) {
              errorMessage = [
                !enResult.success ? `English Push: ${enResult.error}` : null,
                !zhResult.success ? `Chinese Push: ${zhResult.error}` : null
              ].filter(Boolean).join(" | ");
            }
          } else {
            errorMessage = `DingTalk Token exchange failed: [${tokenData.errcode}] ${tokenData.errmsg}`;
            dingtalkApiResponse.push({ error: "Token fail", detail: tokenData });
          }
        } catch (notifyErr) {
          console.error("DingTalk Notification connection error:", notifyErr);
          errorMessage = `Connection to DingTalk failed: ${notifyErr.message}`;
          dingtalkApiResponse.push({ error: notifyErr.message });
        }
      } else {
        if (isMockDingTalk) {
          sentSuccess = true;
          mockPayload = {
            recipientsZh,
            recipientsEn,
            markdownZh: getMsgMarkdown("zh"),
            markdownEn: getMsgMarkdown("en"),
            note: "System is running in Mock Mode. Message simulated successfully.",
            isMockDingTalk,
            hasAgentId: !!agentId
          };
          console.log("[Mock Notification sent]", mockPayload);
        } else if (!agentId) {
          errorMessage = "DingTalk Agent ID (DINGTALK_AGENT_ID) is not configured in Netlify environment variables.";
        } else if (recipientsZh.length === 0 && recipientsEn.length === 0) {
          errorMessage = "\u672A\u627E\u5230\u4EFB\u4F55\u5339\u914D\u4E14\u5173\u8054\u4E86\u9489\u9489\u8D26\u53F7\u7684\u6307\u6D3E\u5B66\u5458\u3002\u8BF7\u786E\u4FDD\u76EE\u6807\u5B66\u5458\u5728\u7528\u6237\u7BA1\u7406\u4E2D\u5DF2\u540C\u6B65\u9489\u9489\uFF0C\u6216\u7BA1\u7406\u5458\u5DF2\u624B\u52A8\u7ED1\u5B9A\u5176\u5DE5\u53F7\u3002 / No matched assignees with bound DingTalk accounts found. Please ensure target users have synced their DingTalk profiles or their UserID is manually bound.";
        }
      }
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          success: sentSuccess,
          error: errorMessage,
          recipientsZhCount: recipientsZh.length,
          recipientsEnCount: recipientsEn.length,
          mockPayload,
          dbError,
          queryLogs,
          isMockFirebase,
          isMockDingTalk,
          dingtalkApiResponse
        })
      };
    }
    if (action === "notifyMaterial") {
      const { recordingId, title, displayId, lecturerName, categoryName, description, targetType, selectedSds, webhookLang } = body;
      if (!recordingId || !title) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing material recordingId or title" }) };
      }
      const markdownBilingual = `![cover](https://learning.mecloudhub.com/images/share-preview.png) 

 ### **\u{1F525} ME \u4E91\u5B66\u5802\u65B0\u589E\u7CBE\u54C1\u7D20\u6750 / ME Cloud Academy - New Premium Recording Released** 

 ---

 **\u{1F4CB} Material Details / \u7D20\u6750\u8BE6\u60C5\uFF1A**
* \u{1F3F7}\uFE0F **ID / \u7D20\u6750\u7F16\u53F7\uFF1A** [${displayId || recordingId}]
* \u{1F3AC} **Title / \u5F55\u97F3\u6807\u9898\uFF1A** ${title}
* \u{1F464} **Lecturer / \u4E3B\u8BB2\u4EBA\uFF1A** ${lecturerName || "\u7CFB\u7EDF\u5BFC\u5E08 / Mentor"}
* \u{1F4C2} **Category / \u5206\u7C7B\u7EBF\uFF1A** ${categoryName || "\u7CBE\u54C1\u63A8\u8350 / Featured"}

 ---

 > \u{1F4A1} **Introduction / \u8BFE\u7A0B\u4ECB\u7ECD\uFF1A**
> ${description || "\u5BFC\u5E08\u503E\u60C5\u63A8\u8350\uFF01\u6B22\u8FCE\u5927\u5BB6\u70B9\u51FB\u4E0B\u65B9\u94FE\u63A5\u7ACB\u5373\u6536\u542C\u5B9E\u6218\u590D\u76D8\u3002 / Highly recommended! Click the link below to listen to the recording."}

 \u6B22\u8FCE\u6536\u542C\uFF01 / Happy listening!`;
      const getMsgMarkdown = (lang) => {
        if (lang === "en") {
          return `![cover](https://learning.mecloudhub.com/images/share-preview.png)

### **\u{1F525} ME Cloud Academy - New Premium Recording Released**

---

**\u{1F4CB} Material Details:**
* \u{1F3F7}\uFE0F **ID:** [${displayId || recordingId}]
* \u{1F3AC} **Title:** ${title}
* \u{1F464} **Lecturer:** ${lecturerName || "Mentor"}
* \u{1F4C2} **Category:** ${categoryName || "Featured"}

---

> \u{1F4A1} **Introduction:**
> ${description || "Highly recommended! Click the link below to listen to the recording."}

Happy listening!`;
        }
        return `![cover](https://learning.mecloudhub.com/images/share-preview.png)

### **\u{1F525} ME \u4E91\u5B66\u5802\u65B0\u589E\u7CBE\u54C1\u5F55\u97F3\u7D20\u6750**

---

**\u{1F4CB} \u7D20\u6750\u8BE6\u60C5\uFF1A**
* \u{1F3F7}\uFE0F **\u7D20\u6750\u7F16\u53F7\uFF1A** [${displayId || recordingId}]
* \u{1F3AC} **\u5F55\u97F3\u6807\u9898\uFF1A** ${title}
* \u{1F464} **\u4E3B\u8BB2\u4EBA\uFF1A** ${lecturerName || "\u7CFB\u7EDF\u5BFC\u5E08"}
* \u{1F4C2} **\u5206\u7C7B\u7EBF\uFF1A** ${categoryName || "\u7CBE\u54C1\u63A8\u8350"}

---

> \u{1F4A1} **\u8BFE\u7A0B\u4ECB\u7ECD\uFF1A**
> ${description || "\u5BFC\u5E08\u503E\u60C5\u63A8\u8350\uFF01\u6B22\u8FCE\u5927\u5BB6\u70B9\u51FB\u4E0B\u65B9\u94FE\u63A5\u7ACB\u5373\u6536\u542C\u5B9E\u6218\u590D\u76D8\u3002"}

\u6B22\u8FCE\u6536\u542C\uFF01`;
      };
      const getMsgBtnText = (lang) => {
        return lang === "en" ? "\u{1F3A7} Listen Online Now" : "\u{1F3A7} \u7ACB\u5373\u5728\u7EBF\u6536\u542C";
      };
      const getMsgTitle = (lang) => {
        return lang === "en" ? "\u{1F525} ME Cloud Academy - New Material" : "\u{1F525} ME \u4E91\u5B66\u5802\u7CBE\u54C1\u5F55\u97F3\u53D1\u5E03";
      };
      let sentSuccess = false;
      let pushType = "none";
      let mockPayload = null;
      let errorMessage = null;
      const isPushToGroup = !targetType || targetType === "group";
      if (isPushToGroup) {
        if (webhookUrl && !webhookUrl.includes("your_")) {
          try {
            pushType = "webhook";
            const urls = webhookUrl.split(",").map((url) => url.trim()).filter(Boolean);
            let webhookTitle = "\u{1F525} ME \u4E91\u5B66\u5802\u7CBE\u54C1\u5F55\u97F3\u53D1\u5E03 / ME Cloud Academy - New Premium Recording Released";
            let webhookText = markdownBilingual;
            let webhookBtnText = "\u{1F3A7} \u7ACB\u5373\u6536\u542C / Listen Now";
            if (webhookLang === "en") {
              webhookTitle = "\u{1F525} ME Cloud Academy - New Premium Recording Released";
              webhookText = getMsgMarkdown("en");
              webhookBtnText = "\u{1F3A7} Listen Now";
            } else if (webhookLang === "zh") {
              webhookTitle = "\u{1F525} ME \u4E91\u5B66\u5802\u65B0\u589E\u7CBE\u54C1\u5F55\u97F3\u7D20\u6750";
              webhookText = getMsgMarkdown("zh");
              webhookBtnText = "\u{1F3A7} \u7ACB\u5373\u6536\u542C";
            }
            const pushPromises = urls.map(async (url) => {
              const webhookRes = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  msgtype: "actionCard",
                  actionCard: {
                    title: webhookTitle,
                    text: webhookText,
                    btnOrientation: "0",
                    btns: [
                      {
                        title: webhookBtnText,
                        actionURL: `dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fhub%3FrecordingId%3D${recordingId}`
                      }
                    ]
                  }
                })
              });
              const resText = await webhookRes.text();
              let parsed;
              try {
                parsed = JSON.parse(resText);
              } catch (e) {
                parsed = { errcode: webhookRes.ok ? 0 : -1, errmsg: resText };
              }
              return parsed;
            });
            const results = await Promise.all(pushPromises);
            const failed = results.filter((r) => r.errcode !== 0);
            if (failed.length === 0) {
              sentSuccess = true;
            } else {
              errorMessage = `Pushed to ${results.length} bots. ${failed.length} failed. Sample Error: ${JSON.stringify(failed[0])}`;
            }
          } catch (webErr) {
            console.error("DingTalk Webhook Push Error:", webErr);
            errorMessage = `Webhook connection error: ${webErr.message}`;
          }
        } else {
          errorMessage = "DingTalk Group Webhook URL (DINGTALK_WEBHOOK_URL) is not configured in Netlify environment variables.";
        }
      } else {
        pushType = targetType === "individuals" ? "targeted_broadcast" : "broadcast";
        const recipientsZh = [];
        const recipientsEn = [];
        const queryLogs = [];
        if (!isMockFirebase) {
          try {
            const db = getFirestoreDb();
            const snapshot = await db.collection("users").where("role", "!=", "super_admin").get();
            snapshot.forEach((doc) => {
              const data = doc.data();
              if (data.dingtalkUserId) {
                const isEnglishSpeaker = !isUserChineseSpeaker(data);
                if (targetType === "individuals" && Array.isArray(selectedSds)) {
                  const userSd = String(data.sd || "").trim().toLowerCase();
                  const userCrmId = String(data.crmId || "").trim().toLowerCase();
                  const sdMatched = selectedSds.some((sd) => {
                    const sdLower = String(sd).trim().toLowerCase();
                    return sdLower === userSd || data.role === "sd" && sdLower === userCrmId;
                  });
                  if (sdMatched) {
                    if (isEnglishSpeaker) {
                      recipientsEn.push(data.dingtalkUserId);
                    } else {
                      recipientsZh.push(data.dingtalkUserId);
                    }
                    queryLogs.push({ uid: doc.id, crmId: data.crmId, sd: data.sd, matched: true, lang: isEnglishSpeaker ? "en" : "zh" });
                  } else {
                    queryLogs.push({ uid: doc.id, crmId: data.crmId, sd: data.sd, matched: false });
                  }
                } else {
                  if (isEnglishSpeaker) {
                    recipientsEn.push(data.dingtalkUserId);
                  } else {
                    recipientsZh.push(data.dingtalkUserId);
                  }
                  queryLogs.push({ uid: doc.id, crmId: data.crmId, sd: data.sd, matched: true, lang: isEnglishSpeaker ? "en" : "zh" });
                }
              }
            });
            console.log(`[Material Push] Recipients: ZH=${recipientsZh.length}, EN=${recipientsEn.length}. TargetType: ${targetType}. SD filters: ${JSON.stringify(selectedSds)}`);
          } catch (err) {
            console.error("Failed to query linked user ids:", err);
          }
        } else {
          recipientsEn.push("dd_mock_sales1");
          recipientsZh.push("dd_mock_sales2");
        }
        const uniqueRecipientsZh = Array.from(new Set(recipientsZh));
        const uniqueRecipientsEn = Array.from(new Set(recipientsEn)).filter((uid) => !uniqueRecipientsZh.includes(uid));
        if (!isMockDingTalk && (uniqueRecipientsZh.length > 0 || uniqueRecipientsEn.length > 0) && agentId) {
          try {
            const tokenRes = await fetch(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
            const tokenData = await tokenRes.json();
            if (tokenData.errcode === 0) {
              const token = tokenData.access_token;
              const sendNotification = async (recipientsList, lang) => {
                if (recipientsList.length === 0) return { success: true };
                const notifyRes = await fetch(`https://oapi.dingtalk.com/topapi/message/corpconversation/asyncsend_v2?access_token=${token}`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    agent_id: parseInt(agentId),
                    userid_list: recipientsList.join(","),
                    msg: {
                      msgtype: "action_card",
                      action_card: {
                        title: getMsgTitle(lang),
                        markdown: getMsgMarkdown(lang),
                        btn_orientation: "0",
                        btn_json_list: [
                          {
                            title: getMsgBtnText(lang),
                            action_url: `dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fhub%3FrecordingId%3D${recordingId}`
                          }
                        ]
                      }
                    }
                  })
                });
                const notifyData = await notifyRes.json();
                if (notifyData.errcode === 0) {
                  return { success: true };
                } else {
                  return { success: false, error: `DingTalk API returned errcode ${notifyData.errcode}: ${notifyData.errmsg}` };
                }
              };
              const enResult = await sendNotification(uniqueRecipientsEn, "en");
              const zhResult = await sendNotification(uniqueRecipientsZh, "zh");
              sentSuccess = enResult.success && zhResult.success;
              if (!sentSuccess) {
                errorMessage = [
                  !enResult.success ? `English Push: ${enResult.error}` : null,
                  !zhResult.success ? `Chinese Push: ${zhResult.error}` : null
                ].filter(Boolean).join(" | ");
              }
            } else {
              errorMessage = `DingTalk Token exchange failed: [${tokenData.errcode}] ${tokenData.errmsg}`;
            }
          } catch (broadcastErr) {
            console.error("DingTalk broadcast error:", broadcastErr);
            errorMessage = `DingTalk Broadcast connection failed: ${broadcastErr.message}`;
          }
        } else {
          if (isMockDingTalk) {
            sentSuccess = true;
            mockPayload = {
              recipientsZh: uniqueRecipientsZh,
              recipientsEn: uniqueRecipientsEn,
              pushType,
              markdownZh: getMsgMarkdown("zh"),
              markdownEn: getMsgMarkdown("en"),
              actionUrl: `dingtalk://dingtalkclient/page/link?url=https%3A%2F%2Flearning.mecloudhub.com%2Fhub%3FrecordingId%3D${recordingId}`,
              queryLogs
            };
            console.log("[Mock Material Push sent]", mockPayload);
          } else if (!agentId) {
            errorMessage = "DingTalk Agent ID (DINGTALK_AGENT_ID) is not configured in Netlify environment variables.";
          } else if (recipientsZh.length === 0 && recipientsEn.length === 0) {
            errorMessage = "\u60A8\u9009\u62E9\u7684\u63A5\u6536\u90E8\u95E8\uFF08\u6309 SD \u7EF4\u5EA6\uFF09\u4E2D\uFF0C\u6CA1\u6709\u4EFB\u4F55\u6210\u5458\u5173\u8054\u4E86\u9489\u9489\u8D26\u53F7\u3002\u8BF7\u786E\u4FDD\u56E2\u961F\u6210\u5458\u5DF2\u5B8C\u6210\u8D26\u53F7\u540C\u6B65\uFF0C\u6216\u7BA1\u7406\u5458\u5DF2\u624B\u52A8\u7ED1\u5B9A\u5176\u5DE5\u53F7\u3002 / No team members in the selected teams have bound their DingTalk accounts. Please ensure members have synced their profiles or their UserID is manually bound.";
          }
        }
      }
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          success: sentSuccess,
          error: errorMessage,
          pushType,
          mockPayload
        })
      };
    }
    if (action === "checkProgress") {
      const { taskId } = body;
      if (!taskId) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing taskId" }) };
      }
      if (isMockDingTalk) {
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: true,
            note: "Running in mock mode. Simulated progress: 100%."
          })
        };
      }
      try {
        const tokenRes = await fetch(`https://oapi.dingtalk.com/gettoken?appkey=${appKey.trim()}&appsecret=${appSecret.trim()}`);
        const tokenData = await tokenRes.json();
        if (tokenData.errcode !== 0) {
          return { statusCode: 500, body: JSON.stringify({ error: `Token exchange failed: ${tokenData.errmsg}` }) };
        }
        const token = tokenData.access_token;
        const parsedAgentId = agentId ? parseInt(agentId.trim()) : null;
        const parsedTaskId = typeof taskId === "number" ? taskId : parseInt(String(taskId).trim());
        const progressRes = await fetch(`https://oapi.dingtalk.com/topapi/message/corpconversation/getsendprogress?access_token=${token}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            agent_id: parsedAgentId,
            task_id: parsedTaskId
          })
        });
        const progressData = await progressRes.json();
        const resultRes = await fetch(`https://oapi.dingtalk.com/topapi/message/corpconversation/getsendresult?access_token=${token}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            agent_id: parsedAgentId,
            task_id: parsedTaskId
          })
        });
        const resultData = await resultRes.json();
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: true,
            debug: {
              agentIdRaw: agentId,
              agentIdParsed: parsedAgentId,
              taskIdRaw: taskId,
              taskIdParsed: parsedTaskId,
              isMockDingTalk,
              isMockFirebase
            },
            progress: progressData,
            result: resultData
          })
        };
      } catch (err) {
        return {
          statusCode: 500,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: false,
            error: err.message
          })
        };
      }
    }
    return { statusCode: 400, body: JSON.stringify({ error: "Unsupported action" }) };
  } catch (error) {
    console.error("DingTalk Handler Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
function getMockUserRecords() {
  return [
    { id: "mock_id_1", crmId: "wuchuan", role: "user", team: "SS-Team1", dep: "SS" },
    { id: "mock_id_2", crmId: "bader", role: "user", team: "CC-Team2", dep: "CC" },
    { id: "mock_id_3", crmId: "ahmed", role: "user", team: "CC-Team1", dep: "CC" },
    { id: "mock_id_4", crmId: "lecturer", role: "sd", team: "Management", dep: "functional" },
    { id: "mock_id_5", crmId: "Serdah", role: "user", team: "SS-Team2", dep: "SS" }
  ];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
