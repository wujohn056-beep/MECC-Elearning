var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var manageUser_exports = {};
__export(manageUser_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(manageUser_exports);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
if (!import_firebase_admin.default.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      import_firebase_admin.default.initializeApp({
        credential: import_firebase_admin.default.credential.cert(serviceAccount)
      });
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error:", error);
  }
}
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    if (!import_firebase_admin.default.apps.length) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Firebase Admin not initialized. Check FIREBASE_SERVICE_ACCOUNT env var in Netlify." })
      };
    }
    const body = JSON.parse(event.body);
    const { action, uid, newPassword } = body;
    if (!uid) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing uid" }) };
    }
    if (action === "delete") {
      await import_firebase_admin.default.auth().deleteUser(uid);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "User deleted successfully from Auth" })
      };
    } else if (action === "resetPassword") {
      const passwordToSet = newPassword || "123456";
      await import_firebase_admin.default.auth().updateUser(uid, {
        password: passwordToSet
      });
      return {
        statusCode: 200,
        body: JSON.stringify({ message: `Password reset successfully to ${passwordToSet}` })
      };
    } else {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid action" }) };
    }
  } catch (error) {
    console.error("manageUser error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
