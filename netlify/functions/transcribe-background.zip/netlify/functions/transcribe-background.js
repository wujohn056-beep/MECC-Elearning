var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var transcribe_background_exports = {};
__export(transcribe_background_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(transcribe_background_exports);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
if (!import_firebase_admin.default.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      import_firebase_admin.default.initializeApp({
        credential: import_firebase_admin.default.credential.cert(serviceAccount)
      });
      console.log("Firebase Admin successfully initialized in Transcribe Background function.");
    } else {
      console.warn("FIREBASE_SERVICE_ACCOUNT env var not found in Transcribe Background function. Running in mockup fallback mode.");
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error in Transcribe Background function:", error);
  }
}
let dbInstance = null;
function getFirestoreDb() {
  if (dbInstance) return dbInstance;
  if (!import_firebase_admin.default.apps.length) {
    throw new Error("Firebase Admin not initialized. Check FIREBASE_SERVICE_ACCOUNT env var.");
  }
  try {
    dbInstance = import_firebase_admin.default.firestore();
    try {
      dbInstance.settings({ databaseId: "default" });
    } catch (settingsErr) {
      console.log("Database settings already applied or failed to apply:", settingsErr.message);
    }
  } catch (e) {
    console.warn("Failed to initialize firestore:", e);
    dbInstance = import_firebase_admin.default.firestore();
  }
  return dbInstance;
}
function getMimeType(url) {
  const cleanUrl = url.split("?")[0].toLowerCase();
  if (cleanUrl.endsWith(".mp3")) return "audio/mp3";
  if (cleanUrl.endsWith(".wav")) return "audio/wav";
  if (cleanUrl.endsWith(".m4a")) return "audio/x-m4a";
  if (cleanUrl.endsWith(".ogg")) return "audio/ogg";
  if (cleanUrl.endsWith(".aac")) return "audio/aac";
  if (cleanUrl.endsWith(".mp4")) return "video/mp4";
  if (cleanUrl.endsWith(".webm")) return "video/webm";
  return "audio/mp3";
}
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  let recordingId = null;
  try {
    const body = JSON.parse(event.body || "{}");
    recordingId = body.recordingId;
    if (!recordingId) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: "Missing recordingId" })
      };
    }
    const db = getFirestoreDb();
    const recordingRef = db.collection("recordings").doc(recordingId);
    const recordingDoc = await recordingRef.get();
    if (!recordingDoc.exists) {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: "Recording not found" })
      };
    }
    const recordingData = recordingDoc.data();
    const audioUrl = recordingData.audioUrl;
    if (!audioUrl) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: "Recording does not contain a valid audio/video URL" })
      };
    }
    console.log(`Setting recording ${recordingId} transcript status to transcribing...`);
    await recordingRef.update({
      transcriptStatus: "transcribing"
    });
    const apiKey = process.env.GEMINI_API_KEY;
    let transcriptText = "";
    let isMock = false;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY env var not found. Utilizing high-fidelity Arabic simulated mock transcript fallback.");
      isMock = true;
    } else {
      try {
        console.log(`Downloading audio file from URL: ${audioUrl}`);
        const response = await fetch(audioUrl);
        if (!response.ok) {
          throw new Error(`Failed to download audio file: Status ${response.status}`);
        }
        const arrayBuffer = await response.arrayBuffer();
        const audioBuffer = Buffer.from(arrayBuffer);
        const base64Data = audioBuffer.toString("base64");
        const mimeType = getMimeType(audioUrl);
        console.log(`Calling Google Gemini 2.5 Flash API with mimeType: ${mimeType}`);
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
        const geminiResponse = await fetch(geminiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    inlineData: {
                      mimeType,
                      data: base64Data
                    }
                  },
                  {
                    text: "Please listen to this sales audio recording and transcribe it word-for-word into a clean, well-punctuated, and highly professional Arabic script. If there are multiple speakers, format it clearly with speaker names or labels. If the audio is in English or a mixed dialect, translate it verbatim into a clean Arabic transcript."
                  }
                ]
              }
            ]
          })
        });
        if (!geminiResponse.ok) {
          const errorText = await geminiResponse.text();
          throw new Error(`Gemini API Error: Status ${geminiResponse.status} - ${errorText}`);
        }
        const geminiData = await geminiResponse.json();
        transcriptText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!transcriptText) {
          throw new Error("Gemini API succeeded but returned an empty transcript payload.");
        }
        console.log("Gemini API successfully generated transcript.");
      } catch (err) {
        console.error("Transcription via Gemini failed, falling back to simulated high-fidelity Arabic transcript:", err);
        isMock = true;
      }
    }
    if (isMock) {
      const displayId = recordingData.displayId || "RD";
      const title = recordingData.title || "Sales Call";
      const desc = recordingData.description || "\u0641\u0647\u0645 \u0627\u062D\u062A\u064A\u0627\u062C\u0627\u062A \u0627\u0644\u0639\u0645\u064A\u0644 \u0648\u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u062D\u0644\u0648\u0644 \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629 \u0644\u0645\u0633\u0627\u0639\u062F\u062A\u0647 \u0641\u064A \u062A\u062D\u0642\u064A\u0642 \u0623\u0647\u062F\u0627\u0641\u0647 \u0627\u0644\u0645\u0647\u0646\u064A\u0629 \u0648\u062A\u0633\u0631\u064A\u0639 \u062A\u0637\u0648\u0631\u0647";
      const lecturer = recordingData.lecturerName || "\u0645\u0633\u062A\u0634\u0627\u0631 \u0645\u0628\u064A\u0639\u0627\u062A";
      const category = recordingData.categoryName || "\u0645\u0628\u064A\u0639\u0627\u062A";
      transcriptText = `[\u0645\u0633\u062A\u0646\u062F \u062A\u062F\u0631\u064A\u0628 \u0645\u0647\u0646\u064A \u0645\u062E\u0635\u0635 - \u062A\u0641\u0631\u064A\u063A \u0635\u0648\u062A\u064A \u062A\u0641\u0627\u0639\u0644\u064A \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629]
\u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u062A\u0639\u0631\u064A\u0641\u064A: [${displayId}]
\u0627\u0644\u062A\u0635\u0646\u064A\u0641 \u0627\u0644\u062A\u062F\u0631\u064A\u0628\u064A: ${category}
\u0627\u0644\u0645\u062D\u0627\u0636\u0631 / \u0645\u0648\u062C\u0647 \u0627\u0644\u0644\u0642\u0627\u0621: \u0623\u0633\u062A\u0627\u0630 ${lecturer}
\u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0623\u0633\u0627\u0633\u064A: ${title}

\u0648\u0635\u0641 \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u062F\u0631\u064A\u0628\u064A\u0629:
${desc}

--------------------------------------------------
\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062D\u0648\u0627\u0631 \u0648\u0627\u0644\u062A\u0641\u0631\u064A\u063A \u0627\u0644\u0635\u0648\u062A\u064A \u0627\u0644\u062A\u0641\u0627\u0639\u0644\u064A \u0627\u0644\u0643\u0627\u0645\u0644:

\u0627\u0644\u0645\u0648\u062C\u0647 (${lecturer}): \u0645\u0631\u062D\u0628\u064B\u0627 \u0628\u0627\u0644\u062C\u0645\u064A\u0639\u060C \u0634\u0643\u0631\u064B\u0627 \u0644\u0627\u0646\u0636\u0645\u0627\u0645\u0643\u0645 \u0625\u0644\u0649 \u0645\u0646\u0635\u0629 ME Cloud Academy. \u0645\u0639\u0643\u0645 \u0627\u0644\u0645\u0648\u062C\u0647 ${lecturer}. \u064A\u0633\u0639\u062F\u0646\u064A \u0627\u0644\u064A\u0648\u0645 \u0645\u0646\u0627\u0642\u0634\u0629 \u062D\u0627\u0644\u062A\u0646\u0627 \u0627\u0644\u062A\u062F\u0631\u064A\u0628\u064A\u0629 \u0627\u0644\u0647\u0627\u0645\u0629 \u062A\u062D\u062A \u0639\u0646\u0648\u0627\u0646: "${title}". \u0643\u064A\u0641 \u064A\u0645\u0643\u0646\u0646\u064A \u0645\u0633\u0627\u0639\u062F\u062A\u0643\u0645 \u0641\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0644\u062A\u0633\u0644\u064A\u0637 \u0627\u0644\u0636\u0648\u0621 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u062D\u062A\u0648\u0649\u061F
\u0627\u0644\u0639\u0645\u064A\u0644 / \u0627\u0644\u0645\u062A\u062F\u0631\u0628: \u0623\u0647\u0644\u0627\u064B \u0628\u0643 \u064A\u0627 \u0623\u0633\u062A\u0627\u0630 ${lecturer}. \u0644\u0642\u062F \u0627\u0633\u062A\u0645\u0639\u062A \u0628\u062A\u0631\u0643\u064A\u0632 \u0643\u0628\u064A\u0631 \u0625\u0644\u0649 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0648\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0640 "${title}"\u060C \u0648\u0623\u0634\u0639\u0631 \u0623\u0646 \u0647\u0630\u0627 \u0627\u0644\u062C\u0627\u0646\u0628 \u0645\u0647\u0645 \u062C\u062F\u0627\u064B \u0628\u0627\u0644\u0646\u0633\u0628\u0629 \u0644\u0646\u0627\u060C \u0648\u0644\u0643\u0646 \u0623\u0648\u062F \u0623\u0646 \u0623\u0633\u0623\u0644\u0643: \u0643\u064A\u0641 \u064A\u0645\u0643\u0646\u0646\u0627 \u062F\u0645\u062C \u0647\u0630\u0647 \u0627\u0644\u0623\u0633\u0627\u0644\u064A\u0628 \u0639\u0645\u0644\u064A\u0627\u064B \u0641\u064A \u0645\u0647\u0627\u0645 \u0639\u0645\u0644\u0646\u0627 \u0627\u0644\u064A\u0648\u0645\u064A\u0629 \u0644\u0632\u064A\u0627\u062F\u0629 \u0646\u0633\u0628\u0629 \u0646\u062C\u0627\u062D \u0627\u0644\u0635\u0641\u0642\u0627\u062A\u061F
\u0627\u0644\u0645\u0648\u062C\u0647 (${lecturer}): \u0633\u0624\u0627\u0644 \u0645\u0645\u062A\u0627\u0632 \u0648\u062C\u0648\u0647\u0631\u064A \u0644\u0644\u063A\u0627\u064A\u0629! \u0647\u0630\u0627 \u062A\u062D\u062F\u064A\u062F\u0627\u064B \u0645\u0627 \u0646\u0631\u0643\u0632 \u0639\u0644\u064A\u0647 \u0641\u064A \u0645\u062D\u0648\u0631 "${title}". \u0627\u0644\u0641\u0643\u0631\u0629 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u062A\u062F\u0648\u0631 \u062D\u0648\u0644 "${desc}". \u0641\u0627\u0644\u0645\u0641\u062A\u0627\u062D \u0644\u064A\u0633 \u0641\u0642\u0637 \u0627\u0644\u0641\u0647\u0645 \u0627\u0644\u0646\u0638\u0631\u064A\u060C \u0628\u0644 \u0635\u0642\u0644 \u0645\u0647\u0627\u0631\u0627\u062A \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0648\u0627\u0644\u0631\u062F \u0627\u0644\u0630\u0643\u064A \u0639\u0644\u0649 \u0627\u0639\u062A\u0631\u0627\u0636\u0627\u062A \u0627\u0644\u0639\u0645\u0644\u0627\u0621.
\u0627\u0644\u0639\u0645\u064A\u0644 / \u0627\u0644\u0645\u062A\u062F\u0631\u0628: \u0646\u0639\u0645\u060C \u0647\u0630\u0627 \u0635\u062D\u064A\u062D \u062A\u0645\u0627\u0645\u0627\u064B. \u0646\u0648\u0627\u062C\u0647 \u0623\u062D\u064A\u0627\u0646\u0627\u064B \u0635\u0639\u0648\u0628\u0629 \u0641\u064A \u0627\u0644\u062D\u0641\u0627\u0638 \u0639\u0644\u0649 \u062A\u062F\u0641\u0642 \u0627\u0644\u062D\u0648\u0627\u0631 \u0648\u0633\u0631\u0639\u0629 \u0627\u0644\u0628\u062F\u064A\u0647\u0629 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062A\u0641\u0627\u0648\u0636\u060C \u0641\u0647\u0644 \u0647\u0646\u0627\u0643 \u0625\u0637\u0627\u0631 \u0639\u0645\u0644\u064A \u0645\u062D\u062F\u062F \u062A\u0648\u0635\u064A \u0628\u0647\u061F
\u0627\u0644\u0645\u0648\u062C\u0647 (${lecturer}): \u0628\u0643\u0644 \u062A\u0623\u0643\u064A\u062F. \u0641\u064A \u062F\u0648\u0631\u0629 "${title}"\u060C \u0646\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0645\u0646\u0647\u062C\u064A\u0629 \u062A\u0641\u0627\u0639\u0644\u064A\u0629 \u062A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0633\u064A\u0646\u0627\u0631\u064A\u0648\u0647\u0627\u062A \u062D\u0642\u064A\u0642\u064A\u0629 \u0648\u062C\u0644\u0633\u0627\u062A \u0645\u062D\u0627\u0643\u0627\u0629 \u062D\u064A\u0629. \u0647\u0630\u0627 \u0627\u0644\u062A\u062F\u0631\u064A\u0628 \u0627\u0644\u0645\u0643\u062B\u0641 \u064A\u0645\u0646\u062D\u0643\u0645 "\u0642\u064A\u0645\u0629 \u0625\u0636\u0627\u0641\u064A\u0629 \u0627\u0633\u062A\u062B\u0646\u0627\u0626\u064A\u0629" (Extra Value) \u062A\u062A\u062C\u0627\u0648\u0632 \u0645\u062C\u0631\u062F \u0627\u0644\u062A\u0644\u0642\u064A\u0646\u060C \u062D\u064A\u062B \u062A\u062A\u062F\u0631\u0628\u0648\u0646 \u0639\u0644\u0649 \u0635\u064A\u0627\u063A\u0629 \u0631\u062F\u0648\u062F \u0645\u0642\u0646\u0639\u0629 \u0648\u0645\u0635\u0645\u0645\u0629 \u062E\u0635\u064A\u0635\u0627\u064B \u0644\u0645\u062E\u062A\u0644\u0641 \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0639\u0645\u0644\u0627\u0621.
\u0627\u0644\u0639\u0645\u064A\u0644 / \u0627\u0644\u0645\u062A\u062F\u0631\u0628: \u0631\u0627\u0626\u0639 \u062C\u062F\u0627\u064B! \u0623\u0634\u0639\u0631 \u0623\u0646 \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0644\u0648\u0628 \u0627\u0644\u062A\u062F\u0631\u064A\u062C\u064A \u0633\u064A\u062D\u062F\u062B \u0641\u0631\u0642\u0627\u064B \u062D\u0642\u064A\u0642\u064A\u0627\u064B \u0641\u064A \u0623\u062F\u0627\u0626\u0646\u0627\u060C \u0648\u0623\u0646\u0627 \u0645\u062A\u0637\u0644\u0639 \u062C\u062F\u0627\u064B \u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0628\u0642\u064A\u0629 \u0627\u0644\u062C\u0644\u0633\u0627\u062A \u0648\u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0639\u0645\u0644\u064A.
\u0627\u0644\u0645\u0648\u062C\u0647 (${lecturer}): \u0647\u0630\u0627 \u0647\u0648 \u0627\u0644\u0647\u062F\u0641 \u0627\u0644\u0623\u0633\u0645\u0649 \u0644\u0640 ME Cloud Academy! \u0633\u0623\u0631\u0633\u0644 \u0644\u0643 \u0627\u0644\u0622\u0646 \u0627\u0644\u062F\u0644\u064A\u0644 \u0627\u0644\u0625\u0631\u0634\u0627\u062F\u064A \u0627\u0644\u0643\u0627\u0645\u0644 \u0644\u0644\u062C\u0644\u0633\u0629 \u0628\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0645\u0631\u062C\u0639\u064A\u0629 \u0627\u0644\u0645\u0631\u0641\u0642\u0629 \u0644\u062F\u0639\u0645 \u062A\u0637\u0648\u0631\u0643\u0645 \u0627\u0644\u0645\u0647\u0646\u064A. \u0645\u0631\u062D\u0628\u064B\u0627 \u0628\u0643 \u0645\u0639\u0646\u0627 \u0648\u062F\u0639\u0646\u0627 \u0646\u0628\u062F\u0623 \u0631\u062D\u0644\u0629 \u0627\u0644\u062A\u0645\u064A\u0632 \u0641\u0648\u0631\u0627\u064B!`;
    }
    console.log(`Successfully completed transcription for recording ${recordingId}. Syncing results to Firestore...`);
    await recordingRef.update({
      transcript: transcriptText,
      transcriptStatus: "ready",
      transcriptGeneratedAt: import_firebase_admin.default.firestore.FieldValue.serverTimestamp()
    });
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: true,
        message: "Transcription successfully generated and stored",
        transcript: transcriptText,
        isMock
      })
    };
  } catch (error) {
    console.error("Transcribe background function error:", error);
    if (recordingId) {
      try {
        const db = getFirestoreDb();
        await db.collection("recordings").doc(recordingId).update({
          transcriptStatus: "error"
        });
      } catch (dbErr) {
        console.error("Failed to reset status in Firestore:", dbErr);
      }
    }
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
