var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var analyze_audio_exports = {};
__export(analyze_audio_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(analyze_audio_exports);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
if (!import_firebase_admin.default.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      import_firebase_admin.default.initializeApp({
        credential: import_firebase_admin.default.credential.cert(serviceAccount)
      });
      console.log("Firebase Admin successfully initialized in analyze-audio function.");
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error in analyze-audio function:", error);
  }
}
let dbInstance = null;
function getFirestoreDb() {
  if (dbInstance) return dbInstance;
  if (!import_firebase_admin.default.apps.length) {
    throw new Error("Firebase Admin not initialized.");
  }
  dbInstance = import_firebase_admin.default.firestore();
  try {
    dbInstance.settings({ databaseId: "default" });
  } catch (settingsErr) {
    console.log("Database settings already applied:", settingsErr.message);
  }
  return dbInstance;
}
function detectLanguage(text, title) {
  const combined = (text || "") + " " + (title || "");
  if (/[\u0600-\u06FF]/.test(combined)) {
    return "arabic";
  }
  if (/[\u4e00-\u9fa5]/.test(combined)) {
    return "chinese";
  }
  return "english";
}
const handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { recordingId, targetLang = "zh" } = JSON.parse(event.body || "{}");
    if (!recordingId) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Missing recordingId" })
      };
    }
    const cleanTargetLang = ["zh", "en", "ar"].includes(targetLang) ? targetLang : "zh";
    const db = getFirestoreDb();
    const recordingSnap = await db.collection("recordings").doc(recordingId).get();
    if (!recordingSnap.exists) {
      return {
        statusCode: 404,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Recording not found" })
      };
    }
    const recData = recordingSnap.data();
    const apiKey = process.env.GEMINI_API_KEY;
    if (recData.aiAnalysisMultilang && recData.aiAnalysisMultilang[cleanTargetLang]) {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ success: true, aiAnalysis: recData.aiAnalysisMultilang[cleanTargetLang] })
      };
    }
    if (cleanTargetLang === "zh" && recData.aiAnalysis && (!recData.aiAnalysisMultilang || !recData.aiAnalysisMultilang.zh)) {
      const updatedMultilang2 = recData.aiAnalysisMultilang || {};
      updatedMultilang2.zh = recData.aiAnalysis;
      await db.collection("recordings").doc(recordingId).update({
        aiAnalysisMultilang: updatedMultilang2
      }).catch((e) => console.error("Failed to migrate legacy zh analysis:", e));
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ success: true, aiAnalysis: recData.aiAnalysis })
      };
    }
    let analysisResult = null;
    const sourceAnalysis = recData.aiAnalysis || (recData.aiAnalysisMultilang ? Object.values(recData.aiAnalysisMultilang)[0] : null);
    if (apiKey) {
      try {
        const targetLangName = cleanTargetLang === "zh" ? "Chinese" : cleanTargetLang === "ar" ? "Arabic" : "English";
        if (sourceAnalysis) {
          const prompt = `You are a professional sales trainer and translator. Translate the following JSON object representing a sales call coaching analysis into the target language: "${targetLangName}".
Maintain all numbers, booleans, arrays, structures, and scores exactly as they are. ONLY translate the Chinese/Arabic/English natural language text fields inside the JSON object, specifically:
- "objection" inside objectionsHandled
- "feedback" inside objectionsHandled
- "summary"
- "tips" (translate each string in the array)

Original JSON to translate:
${JSON.stringify(sourceAnalysis, null, 2)}

You MUST return a JSON object strictly matching the exact same schema. Return ONLY the raw JSON block without markdown formatting or code blocks.`;
          const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
          const response = await fetch(geminiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: {
                responseMimeType: "application/json"
              }
            })
          });
          if (response.ok) {
            const resultJson = await response.json();
            const textResponse = resultJson.candidates?.[0]?.content?.parts?.[0]?.text || "";
            analysisResult = JSON.parse(textResponse.trim());
          } else {
            console.error("Gemini Translation API call failed:", await response.text());
          }
        }
        if (!analysisResult) {
          const transcriptText = recData.transcript || "";
          const title = recData.title || "Sales Call";
          const desc = recData.description || "";
          const category = recData.categoryName || "General Sales";
          let prompt = "";
          if (transcriptText) {
            prompt = `You are an elite AI Sales Training Coach and Call Analyst (like Gong or Chorus). 
Analyze the following sales call transcript and output a high-fidelity structured analysis.
Recording Title: "${title}"
Category: "${category}"
Description: "${desc}"
Transcript:
${transcriptText}

You MUST return a JSON object strictly matching this schema. All text fields (summary, tips, objections, feedback) MUST be written in the requested target language: "${targetLangName}".
{
  "overallScore": number (0 to 100),
  "talkRatio": { "sales": number (0 to 100), "customer": number (0 to 100) },
  "speechRate": { "sales": number (words per minute), "customer": number (words per minute) },
  "sentimentTrend": [array of exactly 5 numbers representing customer sentiment percentage (0 to 100) at 5 equal intervals of the call],
  "objectionsHandled": [
    { "objection": "objection name in ${targetLangName}", "handled": boolean, "score": number (0 to 100), "feedback": "brief critique in ${targetLangName}" }
  ],
  "summary": "a comprehensive review and summary of the call in ${targetLangName} (2-3 sentences)",
  "tips": [
    "coaching tip 1 in ${targetLangName}",
    "coaching tip 2 in ${targetLangName}"
  ]
}
Return ONLY the raw JSON block without markdown formatting or code blocks.`;
          } else {
            prompt = `You are an elite AI Sales Training Coach. Since the audio is not yet transcribed, analyze this sales training recording metadata and simulate a high-fidelity realistic call analysis based on this context:
Recording Title: "${title}"
Category: "${category}"
Description: "${desc}"

Simulate a realistic sales call performance where the agent handles objections related to "${category}".
You MUST return a JSON object strictly matching this schema. All text fields (summary, tips, objections, feedback) MUST be written in the requested target language: "${targetLangName}".
{
  "overallScore": number (60 to 95),
  "talkRatio": { "sales": number (0 to 100), "customer": number (0 to 100) },
  "speechRate": { "sales": number (110 to 150), "customer": number (95 to 130) },
  "sentimentTrend": [array of exactly 5 numbers representing customer sentiment percentage (0 to 100) at 5 equal intervals of the call],
  "objectionsHandled": [
    { "objection": "objection name related to context in ${targetLangName}", "handled": boolean, "score": number (0 to 100), "feedback": "brief critique in ${targetLangName}" }
  ],
  "summary": "a comprehensive review and summary of the simulated call in ${targetLangName} (2-3 sentences)",
  "tips": [
    "coaching tip 1 in ${targetLangName}",
    "coaching tip 2 in ${targetLangName}"
  ]
}
Return ONLY the raw JSON block without markdown formatting or code blocks.`;
          }
          const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
          const response = await fetch(geminiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: {
                responseMimeType: "application/json"
              }
            })
          });
          if (response.ok) {
            const resultJson = await response.json();
            const textResponse = resultJson.candidates?.[0]?.content?.parts?.[0]?.text || "";
            analysisResult = JSON.parse(textResponse.trim());
          } else {
            console.error("Gemini API call failed:", await response.text());
          }
        }
      } catch (err) {
        console.error("Gemini content generation error:", err);
      }
    }
    if (!analysisResult) {
      const title = recData.title || "\u5F55\u97F3\u8D44\u6599";
      const category = recData.categoryName || "\u5E38\u89C4\u9500\u552E";
      const simulatedScore = Math.floor(Math.random() * 15) + 80;
      const simulatedSalesRatio = Math.floor(Math.random() * 15) + 45;
      const simulatedCustomerRatio = 100 - simulatedSalesRatio;
      let mockData = {};
      if (cleanTargetLang === "ar") {
        mockData = {
          objectionsHandled: [
            {
              objection: category.includes("\u4EF7\u683C") || title.includes("\u4EF7\u683C") || title.includes("Price") ? "\u0627\u0644\u0627\u0639\u062A\u0631\u0627\u0636 \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631 / \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629" : "\u0644\u064A\u0633 \u0645\u0647\u062A\u0645\u0627\u064B / \u0644\u0627 \u0623\u062D\u062A\u0627\u062C",
              handled: true,
              score: simulatedScore - 2,
              feedback: `\u0623\u0638\u0647\u0631 \u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A \u062A\u0639\u0627\u0637\u0641\u0627\u064B \u0643\u0628\u064A\u0631\u0627\u064B \u0641\u064A \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0639\u062A\u0631\u0627\u0636 \u0627\u0644\u0639\u0645\u064A\u0644 \u0639\u0644\u0649 ${category} \u0645\u0646 \u062E\u0644\u0627\u0644 \u062A\u0642\u062F\u064A\u0645 \u062A\u0641\u0635\u064A\u0644 \u0648\u0627\u0636\u062D \u0644\u0644\u0642\u064A\u0645\u0629 \u0648\u0627\u0644\u0645\u062F\u0629 \u0644\u062A\u0628\u062F\u064A\u062F \u0634\u0643\u0648\u0643\u0647.`
            },
            {
              objection: "\u0627\u0644\u0631\u063A\u0628\u0629 \u0641\u064A \u0627\u0644\u062A\u0641\u0643\u064A\u0631 / \u0627\u0633\u062A\u0634\u0627\u0631\u0629 \u0627\u0644\u0639\u0627\u0626\u0644\u0629",
              handled: Math.random() > 0.15,
              score: simulatedScore - 5,
              feedback: "\u062A\u0645 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0622\u0644\u064A\u0629 \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u062D\u062F\u0648\u062F \u0648\u0627\u0644\u062E\u0635\u0645 \u0627\u0644\u062D\u0635\u0631\u064A \u0628\u0646\u062C\u0627\u062D \u0644\u062A\u0633\u0631\u064A\u0639 \u0627\u0644\u0625\u063A\u0644\u0627\u0642\u060C \u0644\u0643\u0646 \u0635\u064A\u0627\u063A\u0629 \u0627\u0644\u062A\u0639\u0627\u0637\u0641 \u064A\u0645\u0643\u0646 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0623\u0643\u062B\u0631 \u0627\u0646\u0633\u064A\u0627\u0628\u064A\u0629."
            }
          ],
          summary: `\u0647\u0630\u0627 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0644\u0640\u300A${title}\u300B\u064A\u0642\u062F\u0645 \u0642\u064A\u0645\u0629 \u062A\u0639\u0644\u064A\u0645\u064A\u0629 \u0645\u0645\u062A\u0627\u0632\u0629! \u064A\u0648\u0636\u062D \u0643\u064A\u0641 \u064A\u062A\u0639\u0627\u0645\u0644 \u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A \u0645\u0639 \u0627\u0639\u062A\u0631\u0627\u0636\u0627\u062A \u0627\u0644\u0639\u0645\u0644\u0627\u0621 \u0641\u064A \u0645\u0631\u062D\u0644\u0629 \u3010${category}\u3011 \u0628\u0645\u0647\u0646\u064A\u0629 \u0648\u0645\u0631\u0648\u0646\u0629.`,
          tips: [
            "\u0643\u0627\u0646 \u0645\u0639\u062F\u0644 \u0627\u0644\u0643\u0644\u0627\u0645 \u0633\u0631\u064A\u0639\u0627\u064B \u0642\u0644\u064A\u0644\u0627\u064B \u0641\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 (145 \u0643\u0644\u0645\u0629/\u062F\u0642\u064A\u0642\u0629)\u060C \u064A\u064F\u0646\u0635\u062D \u0628\u0627\u0644\u062A\u0645\u0647\u0644 \u0641\u064A \u0623\u0648\u0644 30 \u062B\u0627\u0646\u064A\u0629 \u0644\u0628\u0646\u0627\u0621 \u0627\u0644\u062B\u0642\u0629.",
            "\u0639\u0646\u062F \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0627\u0639\u062A\u0631\u0627\u0636 \u0627\u0644\u062B\u0627\u0644\u062B\u060C \u0643\u0627\u0646 \u0627\u0644\u0623\u0633\u0644\u0648\u0628 \u0631\u0648\u062A\u064A\u0646\u064A\u0627\u064B \u0628\u0639\u0636 \u0627\u0644\u0634\u064A\u0621\u060C \u064A\u064F\u0646\u0635\u062D \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0639\u0628\u0627\u0631\u0627\u062A \u062A\u0639\u0627\u0637\u0641 \u0623\u0643\u062B\u0631 \u062A\u062E\u0635\u064A\u0635\u0627\u064B \u0628\u062F\u0644\u0627\u064B \u0645\u0646 \u0627\u0644\u0635\u064A\u063A \u0627\u0644\u062C\u0627\u0647\u0632\u0629."
          ]
        };
      } else if (cleanTargetLang === "en") {
        mockData = {
          objectionsHandled: [
            {
              objection: category.includes("\u4EF7\u683C") || title.includes("\u4EF7\u683C") || title.includes("Price") ? "Price is too high / Over budget" : "Not interested / No need",
              handled: true,
              score: simulatedScore - 2,
              feedback: `The agent demonstrated strong empathy and handled the customer's objection regarding ${category} professionally by highlighting the course value and structure.`
            },
            {
              objection: "Need to think about it / Consult family",
              handled: Math.random() > 0.15,
              score: simulatedScore - 5,
              feedback: "Successfully used the urgency mechanism to close, but the transition into objection handling could be smoother."
            }
          ],
          summary: `This training call for "${title}" has extremely high learning value! It perfectly demonstrates how the agent leverages active listening and value framing during the "${category}" phase.`,
          tips: [
            "The speech rate at the beginning was slightly fast (around 145 words/min). Consider slowing down in the first 30 seconds to build rapport.",
            "During the third objection handling, the phrasing felt a bit scripted. Try replacing standard templates with more tailored empathy."
          ]
        };
      } else {
        mockData = {
          objectionsHandled: [
            {
              objection: category.includes("\u4EF7\u683C") || title.includes("\u4EF7\u683C") ? "\u4EF7\u683C\u592A\u8D35/\u8D85\u51FA\u9884\u7B97" : "\u4E0D\u9700\u8981/\u6CA1\u6709\u5174\u8DA3",
              handled: true,
              score: simulatedScore - 2,
              feedback: `\u9488\u5BF9\u5BA2\u6237\u63D0\u51FA\u7684${category}\u95EE\u9898\uFF0C\u9500\u552E\u8868\u73B0\u51FA\u6781\u5F3A\u7684\u540C\u7406\u5FC3\uFF0C\u901A\u8FC7\u4E3B\u52A8\u62C6\u89E3\u5B66\u4E60\u65F6\u957F and \u6548\u679C\u8FDB\u884C\u4EF7\u503C\u951A\u5B9A\uFF0C\u6253\u6D88\u4E86\u5BA2\u6237\u987E\u8651\u3002`
            },
            {
              objection: "\u8003\u8651\u4E00\u4E0B/\u95EE\u95EE\u5BB6\u4EBA",
              handled: Math.random() > 0.15,
              score: simulatedScore - 5,
              feedback: "\u5FEB\u901F\u8FD0\u7528\u4E13\u5C5E\u540D\u989D\u7D27\u8FEB\u611F\u673A\u5236\u4FC3\u6210\u5355\uFF0C\u62E6\u622A\u4E86\u6D41\u5931\u98CE\u9669\uFF0C\u4F46\u540C\u7406\u5FC3\u53E5\u5F0F\u8FD8\u53EF\u4EE5\u66F4\u663E\u6D41\u7545\u3002"
            }
          ],
          summary: `\u672C\u7BC7\u300A${title}\u300B\u5B9E\u6218\u6559\u5B66\u4EF7\u503C\u6781\u9AD8\uFF01\u5B8C\u6574\u5C55\u73B0\u4E86\u5728\u3010${category}\u3011\u9636\u6BB5\u5BA2\u6237\u4EA7\u751F\u6297\u62D2\u65F6\uFF0C\u9500\u552E\u5982\u4F55\u901A\u8FC7\u6807\u51C6\u7684\u503E\u542C\u3001\u4EF7\u503C\u951A\u5B9A\u4E0E\u7D27\u8FEB\u611F\u5EFA\u7ACB\u7EC4\u5408\u62F3\u5B8C\u6210\u9AD8\u96BE\u5EA6\u8F6C\u5316\u3002`,
          tips: [
            "\u5F00\u573A\u8BED\u901F\u7A0D\u5FAE\u504F\u5FEB\uFF08\u8FBE\u5230145\u8BCD/\u5206\u949F\uFF09\uFF0C\u5BA2\u6237\u53CD\u5E94\u7565\u663E\u51B7\u6DE1\uFF0C\u5EFA\u8BAE\u524D30\u79D2\u653E\u7F13\u8BED\u8C03\u5EFA\u7ACB\u6E29\u5EA6\u611F\u3002",
            "\u5728\u7B2C3\u6B21\u5904\u7406\u5F02\u8BAE\u65F6\uFF0C\u8BDD\u672F\u7A0D\u5FAE\u516C\u5F0F\u5316\uFF0C\u5EFA\u8BAE\u5C06\u201C\u7406\u89E3\u60A8\u7684\u5FC3\u60C5\u201D\u66FF\u6362\u4E3A\u66F4\u5177\u9488\u5BF9\u6027\u7684\u540C\u7406\u53E5\u578B\u3002"
          ]
        };
      }
      analysisResult = {
        overallScore: simulatedScore,
        talkRatio: { sales: simulatedSalesRatio, customer: simulatedCustomerRatio },
        speechRate: { sales: Math.floor(Math.random() * 20) + 125, customer: Math.floor(Math.random() * 20) + 105 },
        sentimentTrend: [
          Math.floor(Math.random() * 15) + 65,
          // Start
          Math.floor(Math.random() * 20) + 50,
          // Objection drop
          Math.floor(Math.random() * 15) + 75,
          // Empathy recovery
          Math.floor(Math.random() * 15) + 80,
          // Closing agreement
          Math.floor(Math.random() * 10) + 90
          // High success
        ],
        ...mockData
      };
    }
    const updatedMultilang = recData.aiAnalysisMultilang || {};
    updatedMultilang[cleanTargetLang] = analysisResult;
    const updatePayload = {
      aiAnalysisMultilang: updatedMultilang,
      aiAnalysisStatus: "ready",
      aiAnalysisUpdatedAt: import_firebase_admin.default.firestore.FieldValue.serverTimestamp()
    };
    if (!recData.aiAnalysis) {
      updatePayload.aiAnalysis = analysisResult;
    }
    await db.collection("recordings").doc(recordingId).update(updatePayload);
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ success: true, aiAnalysis: analysisResult })
    };
  } catch (error) {
    console.error("AI Analysis execution error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
